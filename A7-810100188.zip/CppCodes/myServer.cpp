#include "MainObjects/myServer.hpp"
using namespace std;
MyServer::MyServer(int port) : Server(port) {}