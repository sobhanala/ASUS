#ifndef _Libraries_HPP_
#define _Libraries_HPP_
#include <cstdlib>
#include <ctime>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <memory>
#include <math.h>
#include <iomanip>
#endif