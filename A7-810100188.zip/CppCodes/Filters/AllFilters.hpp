#ifndef _AllFilters_HPP_
#define _AllFilters_HPP_
#include "../MainObjects/Filter.hpp"
#include "TagFilter.hpp"
#include "TimeFilter.hpp"
#include "VegetarianFilter.hpp"
#include "RateFilter.hpp"
#endif