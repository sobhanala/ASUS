#ifndef _AllFuncs_HPP_
#define _AllFuncs_HPP_
#include "SearchFuncs.hpp"
#include "OtherFuncs.hpp"
#endif