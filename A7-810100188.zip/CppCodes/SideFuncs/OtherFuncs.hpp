#ifndef _OtherFuncs_HPP_
#define _OtherFuncs_HPP_
bool isNumber(std::string entry);
const std::vector<std::string> divideLine(std::string line, char divider);
void changeErrorText(std::string errorText);
void changeContentJS(const std::string &text);
#endif