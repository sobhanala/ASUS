#ifndef _NotFound_HPP_
#define _NotFound_HPP_
#include "../MainObjects/Error.hpp"
class NotFound : public Error
{
public:
    NotFound();
};
#endif