#ifndef _BadRequest_HPP_
#define _BadRequest_HPP_
#include "../MainObjects/Error.hpp"
class BadRequest : public Error
{
public:
    BadRequest();
};
#endif