#ifndef _Empty_HPP_
#define _Empty_HPP_
#include "../MainObjects/Error.hpp"
class Empty : public Error
{
public:
    Empty();
};
#endif